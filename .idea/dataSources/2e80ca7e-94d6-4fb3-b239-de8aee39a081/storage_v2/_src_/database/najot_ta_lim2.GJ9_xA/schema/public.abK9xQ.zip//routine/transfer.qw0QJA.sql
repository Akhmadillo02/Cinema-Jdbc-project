create procedure transfer(IN sender_id integer, IN receiver_id integer, IN amount numeric)
    language plpgsql
as
$$
declare
begin
    if exists(select * from cards where id = sender_id)
    then
        if exists(select * from cards where id = receiver_id)
        then
            update cards set balance = balance - amount where id = sender_id;
            update cards set balance = balance + amount where id = receiver_id;
        end if;

    end if;
end ;
$$;

alter procedure transfer(integer, integer, numeric) owner to postgres;

