create function get_max()
    returns TABLE(id integer, email character varying)
    language plpgsql
as
$$
    declare
        begin
        return query
        select us.id,us.email
        from users us
        where us.id=
        (select u.id
            from users  u
            order by length(u.email)desc limit 1);

    end;
    $$;

alter function get_max() owner to postgres;

